const path = require("path");
const fs = require('fs');
const os = require('os');
//const rootPath = path.join( __dirname, "../" );

module.exports =
{
    title: "ARCHLine.XP Viewer", // Ez a vegleges app nev.

    //Server url
    getServerUrl: function () {
        return `xxx`; //xxx - a regi
    },

    //Directory of projects on the server
    getServerProjectdir: function () {
        return this.getServerUrl() + `/api/project`;
    },

    //Path of the xkt file on the server
    getServerXktFileUrl: function (modelId) {
        return this.getServerProjectdir() + `/xkt/${modelId}`;
    },

    //Local project path - this is where the files will be downloaded
    getLocalProjectPath: function () {
        return path.join(__dirname, "..", "public", "app", "data", "projects");
    },

    //Local log path - this is where the log files will be stored
    getLocalLogPath: function () {
        return path.join(__dirname, "..", "public", "app", "data", "logs");
    },

    //The local extrajson file path
    getLocalFilePathJson: function (modelId) {
        return this.getLocalProjectPath() + `/${modelId}.json`;
    },

    //The local xkt file path
    getLocalFilePathXkt: function (modelId) {
        return this.getLocalProjectPath() + `/${modelId}.xkt`;
    },

    //Url to update the viewpoints file for a certain model - this will apply the webdav change on the server too
    getViewPointUpdateUrl: function (modelId) {
        return this.getServerUrl() + `/api/entry/updateViewPoints/${modelId}`;
    },

    //Url to get a user - used to determine if a user is demo or not
    getUser: function (userId) {
        return this.getServerUrl() + `/api/getUser/${userId}`;
    },

    writeSummary: function (logFile) {
        return new Promise((resolve, reject) => {
            try {
                const summaryPath = path.join(this.getLocalLogPath(), "summary.txt");
                const logData = fs.readFileSync(logFile, 'utf8');
                const fileNameNoExt = path.basename(logFile, path.extname(logFile));

                const lines = logData.split('\n');
                let finishDownloads = 0;
                let errorDownloads = 0;
                let finishConverts = 0;
                let errorConverts = 0;
                let viewPointModifications = 0;
                let guestUsers = 0;
                const userIds = new Set();

                for (const line of lines) {
                    if (line.includes('FINISH DOWNLOAD')) finishDownloads++;
                    else if (line.includes('ERROR DOWNLOAD')) errorDownloads++;
                    else if (line.includes('FINISH CONVERT')) finishConverts++;
                    else if (line.includes('ERROR CONVERT')) errorConverts++;
                    else if (line.includes('FINISH VIEWPOINT')) viewPointModifications++;
                    else if (line.includes('GUEST')) guestUsers++;

                    const parts = line.split(';');
                    if (parts.length >= 3) {
                        const userId = parts[2].trim();
                        userIds.add(userId);
                    }
                }

                const summaryMsg =
                    `${fileNameNoExt}: ` +
                    `FINISH DOWNLOAD: ${finishDownloads}; ` +
                    `ERROR DOWNLOAD: ${errorDownloads}; ` +
                    `FINISH CONVERT: ${finishConverts}; ` +
                    `ERROR CONVERT: ${errorConverts}; ` +
                    `VIEWPOINT MODIFICATIONS: ${viewPointModifications}; ` +
                    `UNIQUE USERS: ${userIds.size}; ` +
                    `GUEST PROJECT VIEWS: ${guestUsers / 4};\n`;

                console.log(summaryMsg);

                fs.access(summaryPath, fs.constants.F_OK, (err) => {
                    if (err) {
                        fs.writeFile(summaryPath, summaryMsg, (writeErr) => {
                            if (writeErr) return reject(writeErr);
                            resolve();
                        });
                    } else {
                        fs.appendFile(summaryPath, summaryMsg, (appendErr) => {
                            if (appendErr) return reject(appendErr);
                            resolve();
                        });
                    }
                });
            } catch (e) {
                reject(e);
            }
        });
    },

    writeLog: async function (sessionId, userId, msg) {
        const freeMem = os.freemem();

        const d = new Date();
        const date = d.getUTCFullYear() + "-" + (d.getUTCMonth() + 1) + "-" + d.getUTCDate();
        const logPath = path.join(this.getLocalLogPath(), date + ".txt");

        const time = date + " " + d.getUTCHours() + ":" + d.getUTCMinutes() + ":" + d.getUTCSeconds() + "." + d.getUTCMilliseconds() + "-UTC";
        const logMsg = `${time}; ${sessionId}; ${userId}; ${msg}; Free memory: ${(freeMem / 1024 / 1024).toFixed(2)} MB;\n`;

        console.log(logMsg);

        try {
            await fs.promises.access(logPath, fs.constants.F_OK);
            console.log("Adding to log file...");
            await fs.promises.appendFile(logPath, logMsg);
        } catch (err) {
            console.log("Writing new log file...");
            await fs.promises.writeFile(logPath, logMsg);

            // DELETE OLD FILES
            const folderPath = this.getLocalLogPath();
            const ONE_DAY = 24 * 60 * 60 * 1000;
            const now = Date.now();

            try {
                const files = await fs.promises.readdir(folderPath);
                for (const file of files) {
                    if (file === "summary.txt") continue;

                    const filePath = path.join(folderPath, file);
                    try {
                        const stats = await fs.promises.stat(filePath);
                        if (stats.isFile()) {
                            const fileAge = now - stats.mtimeMs;
                            if (fileAge > 0.1 * ONE_DAY) {
                                await this.writeSummary(filePath);  // Await summary before deleting
                                await fs.promises.unlink(filePath);
                                console.log(`Deleted: ${file}`);
                            }
                        }
                    } catch (fileErr) {
                        console.error('Error processing file:', fileErr);
                    }
                }
            } catch (readErr) {
                console.error('Error reading folder:', readErr);
            }
        }
    },

    createUUID: function () {
        return 'xxxxxxxxxxxxxxxx'
            .replace(/[xy]/g, function (c) {
                const r = Math.random() * 16 | 0,
                    v = c == 'x' ? r : (r & 0x3 | 0x8);
                return v.toString(16);
            });
    },

}
