const { parentPort } = require("worker_threads");
const fs = require("fs");
const alCommon = require("../scripts/ALCommon.js");

const convert2xkt = require("../public/javascripts/convert2xkt.cjs.js");
const WebIFC = require("web-ifc/web-ifc-api-node.js");

//Worker thread for the convert
parentPort.on("message", async (job) => {
    var UUID = alCommon.createUUID();
    var outPath = "-";
    try {
        const { sourceBuffer, outputPath } = job;
        outPath = outputPath;
        alCommon.writeLog(UUID, "undefined", "START CONVERT: " + outputPath.replace(/^.*[\\/]/, ''));
        await convert2xkt.convert2xkt({
            WebIFC,
            sourceData: sourceBuffer,
            sourceFormat: "ifc", // case fontos!
            outputXKT: async (xktArrayBuffer) => {
                // Webdav-ra feltoltes - mukodik, de nem kell.
                //await client.putFileContents(targetFileName, xktArrayBuffer, { overwrite: true });
                fs.writeFileSync(outputPath, xktArrayBuffer);
            }
        });
        parentPort.postMessage({ success: true, outputPath, UUID });
    } catch (err) {
        parentPort.postMessage({ success: false, error: err.message, UUID, outPath });
    }
});
