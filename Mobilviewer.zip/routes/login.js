const alCommon = require( "../scripts/ALCommon.js" );
var express = require("express");
var router = express.Router();

router.get( "/", function(req, res, next)
{
	res.render( "login", {title: alCommon.title} );
});

module.exports = router;
