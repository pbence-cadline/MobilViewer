const express = require( 'express' );
const fileUpload = require( 'express-fileupload' );
const router = express.Router();
var path = require( 'path' );
const convert2xkt = require( "../public/javascripts/convert2xkt.cjs.js" );
const WebIFC = require("web-ifc/web-ifc-api-node.js");
const fs = require( 'fs' );

const tmpFilePath = path.join( __dirname, "../tmp" );

router.use( fileUpload( {
	// Configure file uploads with maximum file size 10MB
	limits: { fileSize: 10 * 1024 * 1024 },

	// Temporarily store uploaded files to disk, rather than buffering in memory
	useTempFiles: true,
	tempFileDir: tmpFilePath // '/tmp/'
}));

router.post( '/', async function ( req, res, next )
{
	// Was a file submitted?
	if( !req.files || !req.files.file )
	{
		return res.status(422).send( 'No files were uploaded' );
	}

	const uploadedFile = req.files.file;

	convert2xkt.convert2xkt( {
		WebIFC: WebIFC,
		//sourceData: fs.readFileSync( "rme_advanced_sample_project.ifc" ),
		//sourceData: fs.readFileSync( uploadedFile.tempFilePath ),
		source: uploadedFile.tempFilePath,
		sourceFormat: "ifc", // case fontos!
		outputXKT: ( xtkArrayBuffer ) =>
		{
			//fs.writeFileSync( "rme_advanced_sample_project.ifc.xkt", xtkArrayBuffer );
			fs.writeFileSync( path.join( tmpFilePath, uploadedFile.name + ".xkt"), xtkArrayBuffer );
			//fs.writeFileSync( uploadedFile.name + ".xkt", xtkArrayBuffer );
		}
	} ).then( () =>
	{
		console.log( "Converted." );
	}, ( errMsg ) =>
	{
		console.error( "Conversion failed: " + errMsg )
	} );

	// Print information about the file to the console
	console.log( `File Name: ${uploadedFile.name}` );
	console.log( `File Size: ${uploadedFile.size}` );
	console.log( `File MD5 Hash: ${uploadedFile.md5}` );
	console.log( `File Mime Type: ${uploadedFile.mimetype}` );

	// Return a web page showing information about the file
	res.send( `File Name: ${uploadedFile.name}<br>
				File Path: ${uploadedFile.tempFilePath}<br>
				File Size: ${uploadedFile.size}<br>
				File MD5 Hash: ${uploadedFile.md5}<br>
				File Mime Type: ${uploadedFile.mimetype}` );
});

module.exports = router;
