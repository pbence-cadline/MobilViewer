const express = require( 'express' );
const router = express.Router();
const path = require( 'path' );
const { createClient } = require("webdav");
const { Worker } = require("worker_threads");
const alCommon = require("../scripts/ALCommon.js");

//const rootPath = path.join( __dirname, "../" );
const publicPath = path.join( __dirname, "../public" );
const xktFilePathRel = "app/data/projects/";

var ongoingConverts = [];

/*
Parameterek:
Json - pl.: "{\"path\":\"xxx"}"

Return:
{return:true, xktFilePath:<konvertalt xkt relative pathja>}
{return:false, error:<hibauzenet>}
*/
router.post('/', async function (req, res, next) {

	const token = req.get("Authorization");
	console.log(token);
	if (token != "xxx") {
		res.json({ return: false, error: `Denied` });
		return;
	}

	const convFilePath = req.body.path; // Teljes path.
	console.log(req.body);

	if (convFilePath == null) {
		console.log("No file path!");
		res.json({ return: false, error: `No file path` });
		return;
	}

	if (ongoingConverts.includes(convFilePath)) {
		res.json({ return: false, error: `Already being converted` });
	}
	ongoingConverts.push(convFilePath);
	console.log(ongoingConverts);

	const n = convFilePath.lastIndexOf('/');
	const convFileName = convFilePath.substring(n + 1); // Kinyert fajlnev.
	let targetFileName = convFileName + ".xkt";
	targetFileName = targetFileName.replace(".ifc", "");
	const targetFilePathRel = path.join(xktFilePathRel, targetFileName);
	const targetFilePathAbs = path.join(publicPath, targetFilePathRel);

	const client = createClient
	(
		"xxx",
		{
			username: "xxx",
			password: "xxx"
		}
	);

	//await client.createReadStream("xxx").pipe(fs.createWriteStream(path.join( tmpFilePath, "mycopy.ifc")));
	const buff = await client.getFileContents(convFileName);
	if( !buff )
	{
		res.json( {return:false, error:`Can't open ${convFileName}`} );
		return;
	}

	//Worker thread for the convert - otherwise it stalls the other parts of the server
	const worker = new Worker(path.join(__dirname, "convertWorker.js"));

	const TIMEOUT_MS = 5 * 60 * 1000; // 5 minutes
	const timeout = setTimeout(() => {
		worker.terminate();
		this.writeLog("undefined", "undefined", `FORCED TERMINATION: ${targetFilePathRel.replace(/^.*[\\/]/, '')}`);
		console.error("Worker terminated due to timeout");
		const index = ongoingConverts.indexOf(convFilePath);
		if (index > -1) { // only splice array when item is found
			ongoingConverts.splice(index, 1); // 2nd parameter means remove one item only
		}
	}, TIMEOUT_MS);

	worker.postMessage({
		sourceBuffer: buff,
		outputPath: targetFilePathAbs
	});

	worker.once("message", (result) => {
		clearTimeout(timeout);
		worker.terminate(); //Explicit termination
		if (result.success) {
			alCommon.writeLog(result.UUID, "undefined", "FINISH CONVERT: " + result.outputPath.replace(/^.*[\\/]/, ''));
			console.log("Converted.");
			res.json({ return: true, xktFilePath: targetFilePathRel });
		} else {
			alCommon.writeLog(result.UUID, "undefined", "ERROR CONVERT: " + result.outPath.replace(/^.*[\\/]/, ''));
			console.error("Conversion failed:", result.error);
			res.json({ return: false, error: result.error });
		}
		const index = ongoingConverts.indexOf(convFilePath);
		if (index > -1) { // only splice array when item is found
			ongoingConverts.splice(index, 1); // 2nd parameter means remove one item only
		}
	});

	worker.once("error", (err) => {
	clearTimeout(timeout);
		alCommon.writeLog("undefined", "undefined", "ERROR CONVERT WORKER: " + targetFilePathRel.replace(/^.*[\\/]/, ''));
		console.error("Convert worker error:", err);
		res.json({ return: false, error: err.message });
	});
});

module.exports = router;
