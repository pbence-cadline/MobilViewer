const alCommon = require( "../scripts/ALCommon.js" );
var express = require("express");
var router = express.Router();
var path = require('path');
var fs = require('fs');

router.get( "/", function(req, res, next)
{
	var files = fs.readdirSync(path.join(__dirname, "../public/app/data/projects"), { withFileTypes: true })
		.filter(dirent => dirent.isDirectory())
		.map(dirent => dirent.name);

	let data = {
		title: alCommon.title,
		files: files
	};

	res.render( "models", data );
});

module.exports = router;
