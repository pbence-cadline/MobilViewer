const alCommon = require( "../scripts/ALCommon.js" );
var express = require("express");
var router = express.Router();
const fs = require('fs');
const https = require("https");
const { createClient } = require("webdav");
const path = require('path');

var modelId;
var userId;
var isDemo;
var jsonUrl = "";

/* GET Index.html and download xkt and json */
router.get( "/", function(req, res, next)
{
    modelId = req.query.modelId; // Retrieve modelId from query parameters
    userId = req.query.userId; // Retrieve userId from query parameters
    console.log(`Model ID: ${modelId}`);

    if (!modelId) {
        res.status(500).send("No model ID");
        return;
    }

    isDemo = true;
    if (userId != undefined) {
        https.get(alCommon.getUser(userId), (response) => {
            let data = "";

            // Collect the response data
            response.on("data", (chunk) => {
                data += chunk;
            });

            // Process the complete response
            response.on("end", () => {
                try {
                    const jsonData = JSON.parse(data); // Parse the JSON response
                    isDemo = jsonData.user.demo_user; // Access the "demo_user" value
                    console.log(jsonData.user.demo_user);  
                } catch (error) {
                    console.error("Error parsing JSON:", error);
                }
            });

        }).on("error", (err) => {
            console.error("Request error:", err);
        });
    } else {
        userId = "GUEST";
    }

    //Filepaths from ALCommon
    const filePathJson = alCommon.getLocalFilePathJson(modelId+"TMP");
    const filePathJsonExtra = alCommon.getLocalFilePathJson(modelId);
    const filePath = alCommon.getLocalFilePathXkt(modelId);
    const fileUrl = alCommon.getServerXktFileUrl(modelId);
    var xktUrl = "";

    if (true) {

        //if (fs.existsSync(filePath)) {
        //    fs.unlinkSync(filePath);
        //}

        async function downloadFile(url, path) {
            return new Promise((resolve, reject) => {
                var UUID = alCommon.createUUID();
                alCommon.writeLog(UUID, userId, "START DOWNLOAD: " + path.replace(/^.*[\\/]/, ''));
                const file = fs.createWriteStream(path);

                https.get(url, (response) => {
                    //Check for a successful response (status code 200)
                    if (response.statusCode !== 200) {
                        console.error(`Failed to download file. Server responded with status: ${response.statusCode}`);
                        response.resume(); // Consume response to free up memory
                        file.close(() => fs.unlink(path, () => reject(new Error(`HTTP ${response.statusCode}`))));
                        return;
                    }

                    response.pipe(file);
                    file.on("finish", () => {
                        file.close(resolve);
                        alCommon.writeLog(UUID, userId, "FINISH DOWNLOAD: " + path.replace(/^.*[\\/]/, ''));
                    });
                }).on("error", (err) => {
                    fs.unlink(path, () => reject(err)); // Delete file on error
                    alCommon.writeLog(UUID, userId, "ERROR DOWNLOAD: " + path.replace(/^.*[\\/]/, ''));
                });
            });
        }

        async function processFiles() {
            try {
                //Download the json that contains the paths to the extra json and the xkt
                await downloadFile(fileUrl, filePathJson);
                console.log("Download complete - JSON");

                // Read JSON file only after download completes
                const data = fs.readFileSync(filePathJson, "utf8");
                const jsonData = JSON.parse(data);

                xktUrl = jsonData.path;
                jsonUrl = jsonData.jsonPath;

                if (!fs.existsSync(filePath)) { //Only download xkt if it doesnt exist to avoid redundant downloads -> the converter already downloads it
                    console.log(`Downloading from ${xktUrl}`);
                    await downloadFile(xktUrl, filePath);
                    console.log("Download complete - XKT");
                }

                //Always download the extra json because if it was updated though AL upload it has to be downloaded again
                {
                    await downloadFile(jsonUrl, filePathJsonExtra);
                    console.log("Download complete - Extra Json");
                }

                res.redirect(`/app/index.html?modelId=${modelId}&isDemo=${isDemo}`);
            } catch (error) {
                console.error("Error downloading files:", error);
                res.status(500).send("Error downloading files. The conversion of the file might still be in progress. Try again later. If it is still missing, there might have been a server error, so please try to reupload the file.");
            }
        }

        // Call the function
        processFiles();
    } else {
        console.log(`${filePath} file exists`);
    }
});

router.get('/log-files', (req, res) => {
    const logDir = alCommon.getLocalLogPath();
    fs.readdir(logDir, (err, files) => {
        if (err) {
            console.error('Failed to read log directory:', err);
            return res.status(500).send('Server error');
        }
        // Filter for .txt files only
        const logFiles = files.filter(file => file.endsWith('.txt'));
        res.json(logFiles);
    });
});

router.get('/logs/:filename', (req, res) => {
    const logDir = alCommon.getLocalLogPath();
    const filename = req.params.filename;
    const fullPath = path.join(logDir, filename);

    res.download(fullPath, filename, err => {
        if (err) {
            console.error('Download error:', err);
            res.status(404).send('File not found');
        }
    });
});


//Check if server is healthy
router.get("/health", function (req, res) {
    res.status(200).send("Server is healthy");
});

//Adding viewpoint
router.post('/addViewPoint', (req, res) => {
    if (isDemo) {
        return res.status(503).send('Not added to JSON - DEMO version');
    }
    const filePathJsonExtra = alCommon.getLocalFilePathJson(modelId);
    var UUID = alCommon.createUUID();

    alCommon.writeLog(UUID, userId, "START VIEWPOINT ADD: " + filePathJsonExtra.replace(/^.*[\\/]/, ''));
    try {
        console.log(`Trying to read viewpoints json...`);
        fs.access(filePathJsonExtra, fs.constants.F_OK, (err) => {
            if (err) {
                // If file does not exist, create it with an empty ViewPoints array
                const initialData = { ViewPoints: {} };
                fs.writeFile(filePathJsonExtra, JSON.stringify(initialData, null, 2), (writeErr) => {
                    if (writeErr) return res.status(504).send('Error creating vp JSON');
                    fs.readFile(filePathJsonExtra, 'utf8', (err, data) => {
                        if (err) return res.status(505).send('Error reading vp JSON');
                        let viewPoints = { ViewPoints: {} };

                        // Find the next available key
                        let index = 0;
                        let nextKey;

                        do {
                            nextKey = `ViewPoint${index}`;
                            index++;
                        } while (viewPoints.ViewPoints.hasOwnProperty(nextKey)); // Check if key exists

                        // Add the new viewpoint
                        viewPoints.ViewPoints[nextKey] = req.body;

                        fs.writeFile(filePathJsonExtra, JSON.stringify(viewPoints, null, 2), (err) => {
                            if (err) return res.status(506).send('Error writing vp JSON');
                            res.send({ message: 'Viewpoint added successfully', viewPoints });
                        });
                        updateJson();
                    });
                });
            } else {
                fs.readFile(filePathJsonExtra, 'utf8', (err, data) => {
                    if (err) return res.status(499).send('Error reading vp JSON');

                    let viewPoints;
                    try {
                        viewPoints = JSON.parse(data);
                    } catch (parseError) {
                        viewPoints = { ViewPoints: {} }; //If the format is wrong -> the uploaded extra json file is corrupted/non existant etc -> create a new empty viewpoints obj and overwrite the file
                    }

                    // Ensure `viewPoints` is an object and `ViewPoints` is an object
                    if (typeof viewPoints !== 'object' || viewPoints === null) {
                        viewPoints = {}; // Reset if root is not an object
                    }
                    if (typeof viewPoints.ViewPoints !== 'object' || viewPoints.ViewPoints === null) {
                        viewPoints.ViewPoints = {}; // Ensure ViewPoints is an object
                    }

                    // Find the next available key
                    let index = 0;
                    let nextKey;
                    do {
                        nextKey = `ViewPoint${index}`;
                        index++;
                    } while (viewPoints.ViewPoints.hasOwnProperty(nextKey)); // Ensure unique key

                    // Add the new viewpoint
                    viewPoints.ViewPoints[nextKey] = req.body; // Directly use the incoming body

                    fs.writeFile(filePathJsonExtra, JSON.stringify(viewPoints, null, 2), (err) => {
                        if (err) return res.status(502).send('Error writing vp JSON');
                        res.send({ message: 'Viewpoint added successfully', viewPoints });
                    });

                    updateJson();
                });
            }
        });
    } catch (e) {
    }
    alCommon.writeLog(UUID, userId, "FINISH VIEWPOINT ADD: " + filePathJsonExtra.replace(/^.*[\\/]/, ''));
    
});

//Deleting viewpoint based on id
router.post('/deleteViewPoint', (req, res) => {
    if (isDemo) {
        return res.status(500).send('Not deleted from JSON - DEMO version');
    }
    const filePathJsonExtra = alCommon.getLocalFilePathJson(modelId);
    var UUID = alCommon.createUUID();
    alCommon.writeLog(UUID, userId, "START VIEWPOINT DELETE: " + filePathJsonExtra.replace(/^.*[\\/]/, ''));
    try {
        fs.readFile(filePathJsonExtra, 'utf8', (err, data) => {
            if (err) return res.status(500).send('Error reading file');

            let viewPoints = JSON.parse(data);

            //get the selected index from the request body
            const { index } = req.body;
            const keys = Object.keys(viewPoints.ViewPoints);
            console.log(`${index}`);

            if (index === undefined || index < 0 || index >= keys.length) {
                return res.status(400).send({ message: 'Invalid index' });
            }

            // Delete the selected viewpoint
            delete viewPoints.ViewPoints[index];

            fs.writeFile(filePathJsonExtra, JSON.stringify(viewPoints, null, 2), (err) => {
                if (err) return res.status(500).send('Error writing file');
                res.send({ message: 'Viewpoint added successfully', viewPoints });
            });

            updateJson();  
        });
    } catch (e) {

    }
    alCommon.writeLog(UUID, userId, "FINISH VIEWPOINT DELETE: " + filePathJsonExtra.replace(/^.*[\\/]/, ''));

});

//Update extra json file on webdav and call the api to update it on the server as well
function updateJson() {
    const filePathJsonExtra = alCommon.getLocalFilePathJson(modelId);
    const client = createClient
        (
            "xxx",
            {
                username: "xxx",
                password: "xxx"
            }
        );

    fs.createReadStream(filePathJsonExtra).pipe(client.createWriteStream(`/${modelId}.json`));

    https.get(alCommon.getViewPointUpdateUrl(modelId), (response) => {
    }).on("error", (err) => {
    });
}

module.exports = router;
