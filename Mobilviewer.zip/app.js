//===============================================================================
// ARCHline.XP Web viewer
//
//===============================================================================
var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
var helmet = require('helmet');

var indexRouter = require('./routes/index');
var loginRouter = require('./routes/login');
var modelsRouter = require('./routes/models');
var uploadRouter = require('./routes/upload');
var convertRouter = require('./routes/convert');

var app = express();
//app.use(helmet({
//  frameguard: false,
//}));
//app.use(helmet({
//  frameguard: {
//    action: 'allow-from',
//    domain: 'https://calendar.google.com/calendar/'
//  }
//}))

// View engine beallitas.
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', indexRouter);
app.use('/login', loginRouter);
app.use('/models', modelsRouter);
app.use('/upload', uploadRouter);
app.use('/convert', convertRouter);

// 404 tovabbkuldese hibakezelonek.
app.use( function (req, res, next)
{
	next( createError(404) );
});

// Hibakezelo.
app.use( function ( err, req, res, next )
{
	// Csak fejleszto modban adunk vissza hibareszleteket.
	res.locals.message = err.message;
	res.locals.error = req.app.get('env') === 'development' ? err : {};

	res.status( err.status || 500 );
	res.render( 'error' );
});

module.exports = app;
